# Kyverno Policies

This archive is a placeholder. Populate `base/`, `components/` and
`overlays/_ci/kustomization.yaml` before enabling policy validation.
